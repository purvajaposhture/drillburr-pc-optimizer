# 🐹 DRILLBUR — Windows PC Optimizer

## How to Install & Run

### ✅ Easiest Way (5 seconds)

1. **Make sure Python is installed** → [python.org/downloads](https://python.org/downloads)
   - During install: check ✅ **"Add Python to PATH"**
2. **Double-click `INSTALL.bat`**
   - Installs `psutil` automatically
   - Creates a **Desktop shortcut** 🖥️
   - Creates a **Start Menu entry** 📋
   - Asks if you want to launch now

> For full system access (SFC scan, clean Windows folders): right-click `INSTALL.bat` → **Run as administrator**

---

### 📁 Files in This Package

```
DRILLBUR/
├── INSTALL.bat          ← Double-click this to install
├── BUILD_EXE.bat        ← Optional: build a standalone .exe
├── install.ps1          ← PowerShell installer (called by INSTALL.bat)
├── drillbur_app.py      ← Main app (splash screen + system tray)
├── drillbur_backend.py  ← HTTP server + all API logic
├── Drillbur.html        ← Beautiful frontend UI
└── drillbur.spec        ← PyInstaller config (for building .exe)
```

---

### 🚀 After Installing

**Double-click the DRILLBUR shortcut on your Desktop.**

What happens:
1. A splash screen appears while the backend starts
2. Your browser opens to `http://127.0.0.1:7474`
3. A small **tray widget** appears (bottom-right corner)
   - Click it to open the app
   - Right-click for: Quick Clean, Status, About, Exit

---

### 🔨 Build a Standalone .EXE (Optional)

If you want a single `.exe` that runs without Python installed:

1. Double-click **`BUILD_EXE.bat`**
2. Wait ~2 minutes
3. Find your app at `dist\DRILLBUR\DRILLBUR.exe`
4. Zip the entire `dist\DRILLBUR\` folder to share with anyone

**Requirements for building:**
- Python 3.8+ with pip
- Internet connection (to download PyInstaller)
- ~500 MB free disk space

---

### ⚙️ Manual Launch (no installer)

```cmd
pip install psutil
python drillbur_app.py
```

---

### 🛡️ Features Requiring Administrator

| Feature | Admin needed? |
|---|---|
| Clean browser caches | ❌ No |
| Clean npm/pip caches | ❌ No |
| Flush DNS cache | ✅ Yes |
| Clean Windows Temp | ✅ Yes (some files) |
| Clear Windows Update cache | ✅ Yes |
| System File Check (SFC) | ✅ Yes |
| Clear Event Logs | ✅ Yes |
| Reset Network Stack | ✅ Yes |

To run as admin: use **`DRILLBUR_Admin.bat`** (created by installer)

---

### 🐛 Troubleshooting

| Problem | Fix |
|---|---|
| `python is not recognized` | Install Python, check "Add to PATH" |
| App doesn't open in browser | Manually go to `http://127.0.0.1:7474` |
| Port 7474 already in use | Close the other DRILLBUR instance |
| Live stats show `—` | Install psutil: `pip install psutil` |
| Antivirus blocks .exe | Add an exclusion for `dist\DRILLBUR\` |

---

### 📋 System Requirements

- Windows 10 or Windows 11
- Python 3.8+ (free from python.org)
- 50 MB free space
- Any modern browser (Chrome, Edge, Firefox)

---

*MIT License · Inspired by [Mole (tw93/Mole)](https://github.com/tw93/Mole)*
